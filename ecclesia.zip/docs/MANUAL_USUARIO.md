# Manual de usuario — Ecclesia

_Finanzas parroquiales: ingresos, egresos, cierre mensual y reportes._

## 1. Iniciar sesión

1. Abre la aplicación y pulsa **Ingresar con Google**.
2. Usa la cuenta de Google con la que te registraron. Si ves «Tu cuenta no está autorizada», pide a un administrador que te agregue en **Usuarios**.
3. Para cerrar sesión usa el botón **Cerrar sesión** al pie del menú lateral.

### El menú lateral

Las opciones principales son Períodos, Ingresos, Egresos y Reportes. **Configuración** es un menú ramificado: al pasar el cursor, pulsar (en el celular) o con el teclado, se despliega **hacia la derecha** con **Maestros**, **Usuarios** (solo para los roles que pueden crear usuarios) y **Parroquia**. Con `Esc` se cierra.

## 2. Roles y permisos

| Rol | Qué puede hacer |
|---|---|
| Administrador | Todo, incluida la gestión de usuarios de cualquier rol. |
| Sacerdote | Reabrir períodos, editar maestros y crear contadores y secretarios. |
| Contador | Reabrir períodos, editar maestros y definir la **cuenta contable**. No gestiona usuarios. |
| Secretario | Registra ingresos y egresos, abre y cierra períodos; **no** puede reabrir. Solo consulta los maestros. |

## 3. Períodos

Un período es un mes contable. Los movimientos solo se registran, editan o eliminan en períodos **abiertos**.

- **Abrir:** en **Períodos**, elige año y mes. Pueden existir como máximo **2 períodos abiertos a la vez y deben ser meses consecutivos**.
- **Cerrar:** el período queda de solo lectura. Se muestra su resumen y puedes descargar el **consolidado** (CSV).
- **Reabrir:** solo sacerdote, contador y administrador. Queda registrado quién y cuándo.

## 4. Ingresos y egresos

Cada módulo tiene **dos pantallas**: el listado y el formulario.

### Listado
- Elige el **período** arriba a la derecha.
- Busca por responsable, número de identificación, tipo o descripción, y filtra por **tipo**.
- Pulsa **Nuevo ingreso** / **Nuevo egreso** para crear. Con el lápiz editas y con la papelera eliminas (solo en períodos abiertos).

### Formulario
**Datos del movimiento:** tipo, fecha (dentro de un período abierto), monto y descripción.

- **Ingresos:** la **fecha de registro** es la fecha actual y no se puede cambiar; el período de hoy debe estar abierto. Los **egresos** sí permiten elegir la fecha.
- Si el tipo es un **estipendio**, también son obligatorios la **fecha en que se realizará** la intención (esta sí se puede elegir y cambiar) y la **mención o petición**.
- Si el tipo tiene un **valor sugerido**, el monto aparece ya escrito al elegirlo y puedes cambiarlo.
- Los montos se escriben con el símbolo **$** y separadores de miles, alineados a la derecha; usa la coma (o el punto del teclado numérico) para los centavos.

**Responsable** (quien entrega el dinero en un ingreso, o a quien se le paga en un egreso):

| Campo | Obligatorio | Notas |
|---|---|---|
| Responsable | Sí | Nombre completo o razón social. |
| Dirección | Sí | |
| Tipo de identificación | Sí | NIT, CC o TI. |
| Número de identificación | Sí | CC y TI: solo dígitos. NIT: dígitos, con guion y dígito de verificación opcional (ej. `900123456-7`). |
| Teléfono de contacto | Sí | |
| Correo | No | |

Al guardar vuelves al listado.

### Comprobante de estipendio

Cada estipendio tiene un formato de impresión propio con la información de la parroquia y de la intención (tipo, fechas, mención o petición, responsable, identificación, contacto, valor, quién lo registró y espacio para «Recibido por»). Ocupa **como máximo media hoja carta**: al imprimir varios salen dos por hoja.

- En el listado de **Ingresos**, el botón de la impresora de cada estipendio imprime su comprobante (también en períodos cerrados).
- En **Reportes → Estipendios**, «Imprimir» saca todos los comprobantes del filtro, con este mismo formato.

## 5. Maestros

En **Maestros** se administran los **tipos de ingreso** y **tipos de egreso**: código, nombre, categoría (ingreso: Estipendio o Donación; egreso: Servicio o Gasto) y cuenta contable.

- Solo sacerdote, contador y administrador pueden crear o editar.
- La **cuenta contable** solo la definen el contador y el administrador.
- El **valor sugerido** de cada tipo de estipendio se configura en el panel debajo de la tabla de ingresos (lo editan sacerdote, contador y administrador); vacío = sin sugerencia.
- Un tipo con movimientos no se puede eliminar ni cambiar de código o categoría; puedes **desactivarlo**.

## 6. Reportes

En **Reportes** elige el filtro y pulsa generar:

- **Ingresos / Egresos:** rango de fechas, categoría y tipo. Incluye responsable e identificación.
- **Estipendios:** por fecha de realización de la intención o de registro. Muestra e imprime un **comprobante por estipendio** (ver «Comprobante de estipendio»).
- **Consolidado mensual:** ingresos, egresos y saldo del período.

Con **Imprimir** se abre el diálogo del navegador; ahí puedes elegir **Guardar como PDF**.

## 7. Usuarios

Solo lo ven los roles que pueden crear usuarios. Cada rol gestiona únicamente los roles que puede crear.

- **Nuevo usuario:** correo de Google exacto, nombre (opcional) y rol.
- **Editar:** nombre y rol (el correo no cambia). Nadie puede cambiar su propio rol ni desactivarse.
- **Desactivar:** la persona ya no puede iniciar sesión; sus registros se conservan.

## 8. Parroquia

En **Configuración → Parroquia** se consultan los datos de la parroquia; **solo el sacerdote y el administrador** los editan (botón **Editar datos**, en pantalla aparte).

| Campo | Obligatorio |
|---|---|
| Nombre | Sí |
| Departamento | Sí |
| Ciudad | Sí |
| Dirección | Sí |
| Logo (PNG, JPG o WEBP; se ajusta a 256 px) | No |
| Correo de contacto | No |
| Teléfono de contacto | No |

El nombre y el logo se muestran en el menú lateral y en el encabezado de los reportes impresos.

## 9. Tema

En la barra superior puedes elegir tema **claro**, **oscuro** o **seguir el sistema**. Al imprimir siempre se usan colores claros.

## 10. Mensajes frecuentes

| Mensaje | Qué hacer |
|---|---|
| «El período … no existe / está cerrado» | Abre o reabre el período en **Períodos**. |
| «Solo pueden existir 2 períodos abiertos» | Cierra primero el más antiguo. |
| «El registro está en uso y no se puede eliminar» | Desactívalo en lugar de eliminarlo. |
| «Tu cuenta no está autorizada» | Pide a un administrador que te registre. |
