import { ArrowDownToLine, ArrowUpFromLine, CalendarDays, CircleHelp, Landmark, ListTree, LogOut, Menu, Printer, Settings, Users, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../../auth";
import { cn } from "../../lib/cn";
import { Badge, Button } from "../ui";
import { Brand } from "./Brand";
import { NavItem, SidebarNav, type NavNode } from "./SidebarNav";
import { ThemeToggle } from "./ThemeToggle";

export function AppShell() {
  const { me, logout } = useAuth();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  // Configuración se despliega hacia la derecha; Usuarios solo aparece a los roles que pueden crear usuarios
  const nav: NavNode[] = [
    { to: "/periods", label: "Períodos", Icon: CalendarDays },
    { to: "/incomes", label: "Ingresos", Icon: ArrowDownToLine },
    { to: "/expenses", label: "Egresos", Icon: ArrowUpFromLine },
    { to: "/reports", label: "Reportes", Icon: Printer },
    {
      label: "Configuración", Icon: Settings,
      children: [
        { to: "/masters", label: "Maestros", Icon: ListTree },
        ...((me?.creatableRoles.length ?? 0) > 0 ? [{ to: "/users", label: "Usuarios", Icon: Users }] : []),
        { to: "/parish", label: "Parroquia", Icon: Landmark },
      ],
    },
  ];

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[16.5rem_minmax(0,1fr)] print:!block">
      <div
        onClick={() => setOpen(false)} aria-hidden="true"
        className={cn("fixed inset-0 z-30 print:hidden bg-ink/40 transition-opacity duration-base lg:hidden", open ? "opacity-100" : "pointer-events-none opacity-0")}
      />
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 print:hidden flex w-[16.5rem] flex-col gap-6 border-r border-line bg-surface/95 p-4 shadow-card backdrop-blur",
          "transition-transform duration-slow ease-standard lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 lg:shadow-none",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between px-1 pt-1">
          <Brand />
          <button aria-label="Cerrar menú" onClick={() => setOpen(false)} className="rounded p-1 text-muted hover:bg-mist lg:hidden"><X className="h-5 w-5" /></button>
        </div>
        <SidebarNav items={nav} />
        <div className="mt-auto flex flex-col gap-3">
        <NavItem to="/manual" label="How to use" Icon={CircleHelp} />
        <div className="flex flex-col gap-3 rounded-xl border border-line bg-mist/70 p-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{me?.name ?? me?.email}</p>
            <p className="truncate text-xs text-muted">{me?.email}</p>
            <div className="mt-1.5"><Badge tone="primary"><span className="capitalize">{me?.role}</span></Badge></div>
          </div>
          <Button size="sm" variant="secondary" onClick={logout}><LogOut className="h-3.5 w-3.5" aria-hidden="true" />Cerrar sesión</Button>
          <p className="text-center text-xs text-muted">Ecclesia v{__APP_VERSION__}</p>
        </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="sticky top-0 z-20 print:hidden flex items-center justify-between gap-3 border-b border-line bg-bg/80 px-4 py-3 shadow-soft backdrop-blur-md sm:px-6">
          <button aria-label="Abrir menú" onClick={() => setOpen(true)} className="rounded-md p-1.5 text-ink hover:bg-mist lg:hidden"><Menu className="h-5 w-5" /></button>
          <span className="hidden lg:block" />
          <ThemeToggle />
        </header>
        <main key={pathname} className="mx-auto w-full max-w-5xl animate-fade-in p-4 sm:p-6 print:max-w-none print:p-0">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
